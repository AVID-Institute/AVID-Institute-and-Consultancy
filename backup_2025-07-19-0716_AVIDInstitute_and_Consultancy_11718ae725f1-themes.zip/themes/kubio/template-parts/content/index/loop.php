<div class="wp-block wp-block-kubio-query-loop  position-relative wp-block-kubio-query-loop__container kubio-index__k__vrf0UGkWrN-container kubio-local-188-container gutters-row-lg-2 gutters-row-v-lg-0 gutters-row-md-2 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/query-loop" data-kubio-component="masonry" data-kubio-settings="{&quot;enabled&quot;:true,&quot;targetSelector&quot;:&quot;.wp-block-kubio-query-loop__inner&quot;}">
	<div class="position-relative wp-block-kubio-query-loop__inner kubio-index__k__vrf0UGkWrN-inner kubio-local-188-inner h-row">
		<?php kubio_theme()->get('archive-loop')->render(array (
  'view' => 'content/index/loop-item',
)); ?>
	</div>
</div>
