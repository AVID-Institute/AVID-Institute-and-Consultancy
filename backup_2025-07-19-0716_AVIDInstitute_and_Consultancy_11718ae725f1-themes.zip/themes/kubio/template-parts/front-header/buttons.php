<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<div class="wp-block wp-block-kubio-buttongroup  position-relative wp-block-kubio-buttongroup__outer kubio-front-header__k__9uoTT9gnxCy-outer kubio-local-685-outer h-x-container" data-kubio="kubio/buttongroup">
	<div class="position-relative wp-block-kubio-buttongroup__spacing kubio-front-header__k__9uoTT9gnxCy-spacing kubio-local-685-spacing h-x-container-inner">
		<?php $component->printButtons(); ?>
	</div>
</div>
