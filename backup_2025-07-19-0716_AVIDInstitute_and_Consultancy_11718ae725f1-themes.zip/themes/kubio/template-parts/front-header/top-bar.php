<div class="wp-block wp-block-kubio-navigation-top-bar  kubio-hide-on-mobile position-relative wp-block-kubio-navigation-top-bar__outer kubio-front-header__k__toCQddZ5xwe-outer kubio-local-639-outer d-flex align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/navigation-top-bar">
	<div class="background-wrapper">
		<div class="background-layer background-layer-media-container-lg"></div>
		<div class="background-layer background-layer-media-container-md"></div>
		<div class="background-layer background-layer-media-container"></div>
	</div>
	<div class="position-relative wp-block-kubio-navigation-top-bar__inner kubio-front-header__k__toCQddZ5xwe-inner kubio-local-639-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container kubio-front-header__k__RIVZr4--0St-container kubio-local-640-container gutters-row-lg-0 gutters-row-v-lg-0 gutters-row-md-0 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/row">
			<div class="background-wrapper">
				<div class="background-layer background-layer-media-container-lg"></div>
				<div class="background-layer background-layer-media-container-md"></div>
				<div class="background-layer background-layer-media-container"></div>
			</div>
			<div class="position-relative wp-block-kubio-row__inner kubio-front-header__k__RIVZr4--0St-inner kubio-local-640-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-0 gutters-col-md-0 gutters-col-v-md-0 gutters-col-0 gutters-col-v-0">
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container kubio-front-header__k__f6qqM6zykAu-container kubio-local-641-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner kubio-front-header__k__f6qqM6zykAu-inner kubio-local-641-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align kubio-front-header__k__f6qqM6zykAu-align kubio-local-641-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php kubio_theme()->get('top-bar-list-icons')->render(); ?>
						</div>
					</div>
				</div>
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container kubio-front-header__k__WYzrSI-Wi8J-container kubio-local-649-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner kubio-front-header__k__WYzrSI-Wi8J-inner kubio-local-649-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align kubio-front-header__k__WYzrSI-Wi8J-align kubio-local-649-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php kubio_theme()->get('top-bar-social-icons')->render(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
