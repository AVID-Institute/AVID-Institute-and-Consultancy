<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<div class="wp-block wp-block-kubio-social-icons  position-relative wp-block-kubio-social-icons__outer kubio-front-header__k__wlDkjcCCsVj-outer kubio-local-650-outer social-icons--container" data-kubio="kubio/social-icons">
	<?php $component->printIcons(); ?>
</div>
