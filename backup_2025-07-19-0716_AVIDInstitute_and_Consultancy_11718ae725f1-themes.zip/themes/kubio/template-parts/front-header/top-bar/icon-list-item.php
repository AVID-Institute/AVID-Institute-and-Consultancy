<li class="wp-block wp-block-kubio-iconlistitem  position-relative wp-block-kubio-iconlistitem__item kubio-front-header__k__RxtWacxjkVZ-item kubio-local-647-item" data-kubio="kubio/iconlistitem">
    <a href="<?php echo esc_url( \ColibriWP\Theme\View::getData( 'link_value' ) ); ?>" class="customize-unpreviewable">
        <div class="position-relative wp-block-kubio-iconlistitem__text-wrapper kubio-front-header__k__RxtWacxjkVZ-text-wrapper kubio-local-647-text-wrapper">
            <span class="h-svg-icon wp-block-kubio-iconlistitem__icon kubio-front-header__k__RxtWacxjkVZ-icon kubio-local-647-icon" name="font-awesome/envelope">
                <?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
            </span>
            <span class="position-relative wp-block-kubio-iconlistitem__text kubio-front-header__k__RxtWacxjkVZ-text kubio-local-647-text">
                <?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
            </span>
        </div>
    </a>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper kubio-front-header__k__RxtWacxjkVZ-divider-wrapper kubio-local-647-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper kubio-front-header__k__RxtWacxjkVZ-divider-wrapper kubio-local-647-divider-wrapper"></div>
</li>
