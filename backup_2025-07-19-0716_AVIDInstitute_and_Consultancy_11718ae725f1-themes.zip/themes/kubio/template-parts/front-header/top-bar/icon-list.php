<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<ul class="wp-block wp-block-kubio-iconlist  position-relative wp-block-kubio-iconlist__outer kubio-front-header__k__7yznDknZZGE-outer kubio-local-642-outer ul-list-icon list-type-horizontal-on-desktop list-type-horizontal-on-tablet list-type-horizontal-on-mobile" data-kubio="kubio/iconlist">
	<?php $component->printIcons(); ?>
</ul>
