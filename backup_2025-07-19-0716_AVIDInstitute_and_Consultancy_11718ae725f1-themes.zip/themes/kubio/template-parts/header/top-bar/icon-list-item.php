<li class="wp-block wp-block-kubio-iconlistitem  position-relative wp-block-kubio-iconlistitem__item kubio-header__k__Gazm2NfEdJy-item kubio-local-461-item" data-kubio="kubio/iconlistitem">
	<div class="position-relative wp-block-kubio-iconlistitem__text-wrapper kubio-header__k__Gazm2NfEdJy-text-wrapper kubio-local-461-text-wrapper">
		<span class="h-svg-icon wp-block-kubio-iconlistitem__icon kubio-header__k__Gazm2NfEdJy-icon kubio-local-461-icon" name="font-awesome/envelope">
			<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
		</span>
		<span class="position-relative wp-block-kubio-iconlistitem__text kubio-header__k__Gazm2NfEdJy-text kubio-local-461-text">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
		</span>
	</div>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper kubio-header__k__Gazm2NfEdJy-divider-wrapper kubio-local-461-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper kubio-header__k__Gazm2NfEdJy-divider-wrapper kubio-local-461-divider-wrapper"></div>
</li>
