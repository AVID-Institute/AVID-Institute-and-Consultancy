<a href="<?php echo esc_url(\ColibriWP\Theme\View::getData('link_value')); ?>" class="wp-block wp-block-kubio-social-icon  position-relative wp-block-kubio-social-icon__link kubio-header__k__-aS7vhA_4BQ-link kubio-local-468-link social-icon-link" data-kubio="kubio/social-icon">
	<span class="h-svg-icon wp-block-kubio-social-icon__icon kubio-header__k__-aS7vhA_4BQ-icon kubio-local-468-icon" name="font-awesome/vimeo-square">
		<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
	</span>
</a>
