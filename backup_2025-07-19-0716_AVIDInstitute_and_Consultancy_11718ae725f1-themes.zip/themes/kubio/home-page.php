<?php
/**
 * Template Name: Home Template
 */
?>
<?php get_header(); ?>
<div id="content" data-kubio="kubio/root">
    <?php the_content(); ?>
</div>
<?php
get_footer();
