<?php

/** Kubio - automatically generated file **/

return array(
	'black-wizard'
);
