<?php


namespace Kubio\Theme\Components\FrontHeader;

class TopBar extends \ColibriWP\Theme\Components\FrontHeader\TopBar {

	static $settings_prefix = 'front-header.navigation.';

}
