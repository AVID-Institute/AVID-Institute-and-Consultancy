<?php

get_header();

kubio_theme()->get( 'main' )->render();

get_footer();
