<div class="container">
    <div class="quran-verse">
        <div class="verse-arabic">
            <p>يُؤۡتِي ٱلۡحِكۡمَةَ مَن يَشَآءُۚ وَمَن يُؤۡتَ ٱلۡحِكۡمَةَ فَقَدۡ أُوتِيَ خَيۡرٗا كَثِيرٗاۗ</p>
        </div>
        <div class="verse-translation">
            <p>"He grants wisdom to whom He wills, and whoever has been granted wisdom has certainly been given much good." (Quran 2:269)</p>
        </div>
    </div>
</div>