<?php
get_header();
?>

    <section class="hero-section">
        <?php get_template_part('template-parts/hero-section'); ?>
    </section>

    <section class="quran-verse-section">
        <?php get_template_part('template-parts/quran-verse'); ?>
    </section>

    <section class="courses-section">
        <div class="container">
            <h2 class="section-title">Our Courses</h2>
            <?php get_template_part('template-parts/courses'); ?>
        </div>
    </section>

<?php
get_footer();