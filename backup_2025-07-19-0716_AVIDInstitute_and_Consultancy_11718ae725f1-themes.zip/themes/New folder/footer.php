        </main>

        <footer class="site-footer">
            <div class="container">
                <div class="footer-widgets">
                    <?php if (is_active_sidebar('footer-widgets')) : ?>
                        <?php dynamic_sidebar('footer-widgets'); ?>
                    <?php endif; ?>
                </div>
                
                <div class="footer-bottom">
                    <div class="copyright">
                        &copy; <?php echo date('Y'); ?> AVID Institute & Consultancy. All rights reserved.
                    </div>
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'footer',
                            'menu_class'     => 'footer-menu',
                            'depth'          => 1,
                        )
                    );
                    ?>
                </div>
            </div>
        </footer>

        <?php wp_footer(); ?>
    </body>
</html>