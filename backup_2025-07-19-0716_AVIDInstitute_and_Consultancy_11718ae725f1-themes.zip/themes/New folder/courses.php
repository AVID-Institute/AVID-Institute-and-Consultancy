<div class="courses-grid">
    <?php
    $courses = new WP_Query(array(
        'post_type' => 'course',
        'posts_per_page' => 3
    ));

    if ($courses->have_posts()) :
        while ($courses->have_posts()) : $courses->the_post(); ?>
            <article class="course-card">
                <div class="course-thumbnail">
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="course-content">
                    <h3><?php the_title(); ?></h3>
                    <?php the_excerpt(); ?>
                    <a href="<?php the_permalink(); ?>" class="btn">Learn More</a>
                </div>
            </article>
        <?php endwhile;
        wp_reset_postdata();
    else :
        echo '<p>No courses found.</p>';
    endif;
    ?>
</div>