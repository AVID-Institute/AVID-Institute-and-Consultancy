<div class="hero-content">
    <div class="container">
        <h1>Bridging Divine Wisdom & Modern Knowledge</h1>
        <p>Explore our programs in Islamic theology, philosophy, and scientific inquiry</p>
        <a href="<?php echo esc_url(get_permalink(get_page_by_path('courses'))); ?>" class="btn">View Courses</a>
    </div>
</div>